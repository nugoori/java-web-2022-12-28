package board;

import java.util.ArrayList;
import java.util.List;

// WAS 에서 처리하는 역할
// 회원 등록
// 회원 정보 보기
// 회원 정보 수정
// 회원 삭제
// 회원 리스트

// C. R. U. D.
public class Main {
	private List<User> database = new ArrayList<User>(); 
	
	// 회원 등록
	// id는 0이상의 수 여야 하고 password, name, telNumber 는 빈값이 아니면서 null도 아니어야 함
	private boolean createUser(int id, String password, String name, String telNumber) {
		// 파라미터가 정상적인 값인지 검증
		if (id < 0) return false;
		if (password.isEmpty() || name.isEmpty() || telNumber.isEmpty()) return false;
		if (password == null || name == null || telNumber == null) return false;
		// id 중복 체크
		if (checkOverlap(id)) return false;
		
		// 관리하고자 하는 객채를 생성
		User user = new User(id, password, name, telNumber);
		// 생성한 객체를 데이터베이스에 삽입
		database.add(user);
		// 삽입 결과를 반환
		return true;
	}
	// 회원 정보 보기
	private User readUser(int id) {
		// 파라미터가 정상적인 값인지 검증
		if ( id < 0) return null;
		// database에서 해당 id를 검색
		User user = selectUser(id);
		// 검색 결과를 반환
		return user;
	}
	// 회원 정보 수정
	private User updateUser() {
		return null;
	}
	// 회원 삭제
	private boolean deleteUser() {
		return false;
	}
	// 회원 리스트
	private List<User> readUserList() {
		return null;
	}
	
	// 메인 메서드
	public static void main(String[] args) {
		

	}

	// 회원 아이디가 중복되는지 검사하는 메서드
	private boolean checkOverlap(int id) {
		for (User user : database) {
			if (user.getId() == id) return true;
		}
		return false;
	}
	
	// 특정 회원 id를 database에서 검색하는 메서드 > 원래 SQL에서 담당
	private User selectUser(int id) {
		for (User user : database) {
			if (user.getId() == id) return user;
		}
		return null;
	}
	
	
}









